# Resume Screening using NLP

> Screens Good resume using NLP

![image](main_web_app/Images/logo.png)

## How to Setup ?

```bash
cd /path/to/folder
pip install -r requirements.txt
```

## How to run ?

```bash
cd main_web_app
python -m streamlit run app.py
```
> Show reports in a streamlit webapp.
